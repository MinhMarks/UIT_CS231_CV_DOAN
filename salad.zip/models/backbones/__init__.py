from .resnet import ResNet
from .dinov2 import DINOv2
